let body = document.body;
let topBar = document.querySelector("h1");
let nav = document.querySelector(".nav");
let I = document.querySelector(".I");
let A = document.querySelector(".A");
let B = document.querySelector(".Button");
let P = document.querySelector(".P");
let wrapper = document.querySelector(".wrapper");
let settings = document.querySelector(".settings");
let blueScreen = document.querySelector(".blueScreen");
let greenScreen = document.querySelector(".greenScreen");

function navExpand() {
  nav.style.width = "140px";
  I.innerHTML = "Ian";
  I.style.width = "140px";
  I.style.boxShadow = "-1px 3px 3px #9b9d68";
  A.innerHTML = "About";
  B.innerHTML = "Button";
  P.innerHTML = "Projects";
  settings.style.left = "-200px";
  settings.setAttribute("onclick", "navBack()");
}

function navBack() {
  nav.style.width = "44px";
  I.innerHTML = "I";
  I.style.left = "0px";
  I.style.width = "44px";
  A.innerHTML = "A";
  B.innerHTML = "B";
  P.innerHTML = "P";
  settings.style.left = "-60px";
  settings.setAttribute("onclick", "navExpand()");
}

function Iexpand() {
  I.style.borderRight = "0px";
  topBar.style.transition = "300ms";
  topBar.style.height = "100vh";
  I.setAttribute("onclick", "Iback()");

  topBar.setAttribute("onmouseover", "");
  topBar.setAttribute("onmouseout", "");
}

function Iback() {
  I.style.borderRight = "1px";
  topBar.style.transition = "200ms";
  topBar.style.height = "48px";
  I.setAttribute("onclick", "Iexpand()");

  topBar.setAttribute("onmouseover", "topBarHover()");
  topBar.setAttribute("onmouseout", "topBarBack()");
}

function topBarHover() {
  topBar.style.height = "53px";
  I.style.height = "53px";
  topBar.style.boxShadow = "0 0 0 #9b9d68";
  I.style.boxShadow = "0 0 0";
}

function topBarBack() {
  topBar.style.height = "48px";
  topBar.style.boxShadow = "0 5px 3px black";
  I.style.height = "48px";
  I.style.boxShadow = "0 5px 3px black";
}

function blueScreenExpand() {
  blueScreen.style.backgroundColor = "cornflowerblue";
  A.setAttribute("onclick", "blueScreenBack()");
}

function blueScreenBack() {
  blueScreen.style.backgroundColor = "transparent";
  A.setAttribute("onclick", "blueScreenExpand()");
}

function greenScreenExpand() {
  greenScreen.style.backgroundColor = "#405540";
  B.setAttribute("onclick", "greenScreenBack()");
}

function greenScreenBack() {
  greenScreen.style.backgroundColor = "transparent";
  B.setAttribute("onclick", "greenScreenExpand()");
}
